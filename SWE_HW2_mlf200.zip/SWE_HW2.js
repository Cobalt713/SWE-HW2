const fs = require('fs');
var readline = require('readline');

//time validation program from Homework 1, slightly modified to better fit the uses of Homework 2
function validTime(time){
    //save specific digits in the console input from user to time/date variables
    var year =  time.substr(0,4);
    var month =  time.substr(4,2);
    var day = time.substr(6,2);
    var Tval = time.substr(8,1);
    var hour =  time.substr(9,2);
    var minute = time.substr(11,2);
    var second = time.substr(13,2);

    //Checks to see if there are any incorrect values in the input, in regards to whether or not they are integers
    var firstHalf = time.substr(0,8);
    var secondHalf = time.substr(9,6);
    
    error = false;
    leapYear = false;

    //If an invalid value is detected, if the length of the string is incorrect, if the middle value of
    //the input is NOT T as dictated in the directions, or the second/minute amount is too large, an error is declared
    if(hasInvalidVal(firstHalf) || hasInvalidVal(secondHalf) || !(time.length==15) || Tval !='T' || minute>59 || second>59){
      error = true;
    }
    
    //determines if the year in question is a leap year to determine if February has 28 or 29 days
    if( 0 == year%4){
      leapYear = true;
    }

    //determines what month name must be used based off of the 2 digit number, if the value doesnt correspond to a month then an error is reported
    switch(month){
      case "01":
        monthName = "January";
        if(day>31)
          error = true;
        break;
      case "02":
        monthName = "February";
        if(day>28 && !leapYear)
          error = true;
        else if(day>29 && leapYear)
          error = true;
        break;
      case "03":
        monthName = "March";
        if(day>31)
          error = true;
        break;
      case "04":
        monthName = "April";
        if(day>30)
          error = true;
        break;
      case "05":
        monthName = "May";
        if(day>31)
          error = true;
        break;
      case "06":
        monthName = "June";
        if(day>30)
          error = true;
        break;
      case "07":
        monthName = "July";
        if(day>31)
          error = true;
        break;
      case "08":
        monthName = "August";
        if(day>31)
          error = true;
        break;
      case "09":
        monthName = "September";
        if(day>30)
          error = true;
        break;
      case "10":
        monthName = "October";
        if(day>31)
          error = true;
        break;
      case "11":
        monthName = "November";
        if(day>30)
          error = true;
        break;
      case "12":
        monthName = "December";
        if(day>31)
          error = true;
        break;
      default:
        monthName = null;
        error = true;
    }

    //checks if the day is 0, which is invalid so error boolean becomes true
    if(day ==0){
      error = true;
    }

    //Determines whether the time is in the AM or PM, if the hours is outside the range of 0-23 hours then there is an error
    if(hour>11 && hour <24){
      AMPM = "PM";
    }else if(hour>=0 && hour<12){
      AMPM = "AM"
    }else{
      AMPM = null;
      error = true;
    }

    //executes the final print out the console, returning a date/time or a declaration of an error
    
    let Date = {};
    if(error){
      //Send error message in chat if there appears to be an issue with the inputs
      Date = `There appears to be an error with the input, please try again.`;
    }
    else if(second>0){
      Date = `${monthName} ${day}, ${year}, at ${hour}:${minute}:${second} ${AMPM}`;
    }
    else if (minute>0){
      Date = `${monthName} ${day}, ${year}, at ${hour}:${minute} ${AMPM}`;
    }
    else{
      Date = `${monthName} ${day}, ${year}, at ${hour} ${AMPM}`;
    }
    
    return Date;
  }


//
//
//SWE HW2 main file reading portion
//
//

fs.readFile('records.txt', 'utf8', (err, data)=>{
    if(err){
        console.error(err);
        return;
    }
    data = String(data);
    //console.log(data);
    readRecords(data);
});


//main function that reads, interprets, and checks/confirms the values from the records.txt document with the relevant info
function readRecords(data){
    const lineArray = data.split(/\r?\n|\r|\n/g); //splits the text file in a line by line format
    arrLen = lineArray.length;
    var record = new Object;
    var recordList = new Array();
    var error = false;
    errorMessage = "";

    //keeps track of what line from the text file the program is on, and what record it should be working with (changes after each END call)
    currentLine = 0;
    currentRecord = 0;

    //this variable keeps track of how many times each specific type of line has been called to see if they have been called equally
    var Counters = [0, 0, 0, 0, 0, 0, 0];

    //loops through the entire text document
    while(currentLine<arrLen){
      //break any given line into 2 portions, the part before the colon and the part after
        firstPart = lineArray[currentLine].slice(0,lineArray[currentLine].indexOf(":"));
        secondPart = lineArray[currentLine].slice(lineArray[currentLine].indexOf(":")+1,lineArray[currentLine].length);

    //switch case that checks to see if the firstPart of a line matches any of the known parameters, basing its next steps on what word the firstPart is
    switch(firstPart.toUpperCase()){
        case "BEGIN":
          Counters[0]++;
            if(secondPart == "RECORD"){
                //resets record values for next iteration of record to be saved.  Done at the beginning and end of record-keeping cycle
                record.identifier = "";
                record.weight == "";
                record.time == "";
                record.unit == "";
                record.color == "";
            }else{  //if the secondpart shows something that isn't RECORD then an error is reported
                errorMessage = errorMessage+"ERROR:  The second portion of the BEGIN line in record #"+(currentRecord+1)+" should read RECORD.\n";
                error = true;
            }
            break;
        case "IDENTIFIER":
          Counters[1]++;
            //if the secondPart doesnt fit the 4 digit number format, then an error is declared
            if(secondPart.length > 4 || secondPart<0||isNaN(secondPart)){   
                errorMessage = errorMessage+"ERROR:  The Identifier in record #"+(currentRecord+1)+" should be a 4 digit number.\n";
                error = true;
            }else{
                record.identifier = secondPart;
            }
            break;
        case "TIME":
          Counters[2]++;
          //checks to see if the time is a valid amount and in the right format, calling upon an earlier function from homework 1 to check
            if(validTime(secondPart) == `There appears to be an error with the input, please try again.`){
                errorMessage = errorMessage+"ERROR:  The time value included in record #"+(currentRecord+1)+" is not a valid time/date.\n";
                error = true;
            } else {
                record.time = secondPart;
            }
            break;
        case "WEIGHT":
          Counters[3]++;
            if(secondPart == ""){           //this checks if the input for weight is blank since its optional, if length is 1 then its blank
                record.weight = "";    
            } else if(isNaN(secondPart)){        //if the input for weight is not a number, return an error
                errorMessage = errorMessage+"ERROR:  The value left for weight in record #"+(currentRecord+1)+" is incorrect, make sure its either blank or some number.\n";
                error = true;
            } else {
                record.weight = secondPart;             //input is valid, save it to weight value for
            }
            break;
        case "UNITS":
          Counters[4]++;
            //checks to see if the units are in lbs or kg,and checks to ensure the weight value is not left blank and is a number
            if((secondPart == "lbs" || secondPart == "kg") &&( !(isNaN(record.weight)) && !(record.weight == ""))){
                record.unit = secondPart;
            } else if(secondPart == ""){ 
                record.unit = "";
            } else{
                errorMessage = errorMessage+"ERROR:  The unit value "+secondPart+" in record #"+(currentRecord+1)+" is either invalid or used when no valid weight value is given.\n";
                error = true;
            }
            break;    
        case "COLOR":
          Counters[5]++;
            if(secondPart == ""){  //blank values are acceptable
                record.color = "";
            } else if(!isNaN(secondPart)){  //if the input is a number, then an error is reported as this cannot be a color
                errorMessage = errorMessage+"ERROR:  The color value given in record #"+(currentRecord+1)+" is a number rather than a color.\n";
                error = true;
            }else { //as long as the value is not a number, then given the large amount of potential colors any written output is accepted
                record.color = secondPart;
            }
            break;
        case "END":
          Counters[6]++;
          //if the secondPart reads as anything other than RECORD then an error is reported
            if(secondPart != "RECORD"){ 
                errorMessage = errorMessage+"ERROR:  The second portion of the END line in record #"+(currentRecord+1)+" should read RECORD.\n";
                error = true;
            }
            else{
                recordList.push(record);
                
                //resets values for next iteration of record to be saved.  Done at the beginning and end of record-keeping cycle
                var record = new Object;
                record.identifier = "";
                record.weight == "";
                record.time == "";
                record.unit == "";
                record.color == "";

                currentRecord++;
            }
            break;
          default:
            //occurs whenever there is an incorrect/missing/blank value in the firstPart of the line
            error = true;
            errorMessage = errorMessage+"ERROR:  Line #"+(currentLine+1)+" doesn't have a valid initial value or is left blank.\n";
        }
        currentLine++;
    }
    
    //checks to see if theres too many instances of one particular line/value being called from the text document
    for(let i = 1;i<Counters.length-1;i++){
      if(Counters[i] > Counters[0] && Counters[0] == Counters[6]){
        error = true;
        errorMessage = errorMessage+"ERROR:  There are extra instances of lines being called.\n";
        break;
      }
    }

    //if theres an error return the existing error message and exit the program, if its specifically a 
    if(error){
      return errorMessage;
    } else {
      
      var sortedList = new Array();
      sortedList = recordList;

    //this segment of code is the section where the input from the text file then gets sorted
    sortedList.sort((recordA,recordB)=>{
      recordA = recordA.time.toLowerCase();
      recordB = recordB.time.toLowerCase();
      if(recordA < recordB){
        return -1;
      }
      if(recordA > recordB){
        return 1;
      }     
      return 0;
    });

    //rewrite the values which are in sorted order to a string which contains the rest of the format for the record-file
    var sortedRecords = "";
    for(let i = 0;i<sortedList.length;i++){
      sortedRecords = sortedRecords+"BEGIN:RECORD\nIDENTIFIER:"+sortedList[i].identifier+"\nTIME:"+sortedList[i].time+"\nWEIGHT:"+sortedList[i].weight+"\nUNITS:"+sortedList[i].unit+"\nCOLOR:"+sortedList[i].color+"\nEND:RECORD";
      if(sortedList.length != i+1){
        sortedRecords = sortedRecords+"\n"
      }
      
    }
    //console.log(sortedRecords);
    
    //write the sorted records string to the sortedRecords.txt document
    fs.writeFile('sortedRecords.txt', sortedRecords, err=>{
      if(err){
        console.err;
        return;
      }
    });
    //return the string of the sorted records, now in the proper format
    return toString(sortedRecords);
    }
}

//checks to ensure that a 'number' contains only digits and no additional values
function hasInvalidVal(s) {
    return s.indexOf(' ') + s.indexOf('.') +s.indexOf(',') >= 0;
}



module.exports = {readRecords};