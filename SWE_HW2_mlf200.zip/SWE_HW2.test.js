
const main = require("./SWE_HW2")
const fs = require('fs')

describe('Successful Input:', ()=>{
    test("Places records in order (basic 5 inputs, out of order initially)",()=>{
        let tempA = fs.readFileSync('./records.txt','utf-8');
        let tempB = fs.readFileSync('./goodOutput.txt','utf-8');
        expect(toString(main.readRecords(tempA))).toBe(toString(tempB));    
    })
    test("Places records in order (with only 1 input)",()=>{
        let tempA = fs.readFileSync('./singleRecord.txt','utf-8');
        let tempB = fs.readFileSync('./singleOutput.txt','utf-8');
        expect(main.readRecords(tempA)).toBe(toString(tempB));    
    })
});

describe('Non-Successful Inputs:', ()=>{
    test("Invalid term used in a BEGIN:RECORD line (input is BEGIN:INVALIDVALUEEXAMPLE)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/badBegin.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  The second portion of the BEGIN line in record #2 should read RECORD.\n"); 
    })
    test("Invalid time/date is used (month value is 13 for item 0003)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/badTime.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  The time value included in record #3 is not a valid time/date.\n"); 
    })
    test("Invalid identifier is used (ID for the first record is 00001, too long)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/badIdentifier.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  The Identifier in record #1 should be a 4 digit number.\n"); 
    })
    test("Invalid weight is used (weight is 120lbs, including letters making it not a valid number)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/badWeight.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  The value left for weight in record #2 is incorrect, make sure its either blank or some number.\nERROR:  The unit value lbs in record #2 is either invalid or used when no valid weight value is given.\n"); 
    })
    test("Invalid unit is used (unit value given is not valid weight unit: calories)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/badUnit.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  The unit value calories in record #2 is either invalid or used when no valid weight value is given.\n"); 
    })
    test("Invalid color is given (color value given is a number: 245)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/badColor.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  The color value given in record #3 is a number rather than a color.\n"); 
    })
    test("Invalid term used at the start of a line (END:RECORD instead reads NED:RECORD for the first record)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/badFormat.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  Line #7 doesn't have a valid initial value or is left blank.\n"); 
    })
    test("A line in the documentation is missing (line #12, the Units line is left blank)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/missingLine.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  Line #12 doesn't have a valid initial value or is left blank.\n"); 
    })
    test("Unit is used when no weight is given (unit is kg, when weight is left blank in record 1)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/noWeight.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  The unit value kg in record #1 is either invalid or used when no valid weight value is given.\n"); 
    })
    test("An extra IDENTIFIER:VALUE is placed after the start of record 2 (there are two IDENTIFIER lines back to back with different values)",()=>{
        let temp = fs.readFileSync('./BadRecordInputs/repeatId.txt','utf-8');
        expect(main.readRecords(temp)).toBe("ERROR:  There are extra instances of lines being called.\n"); 
    })
    
});
